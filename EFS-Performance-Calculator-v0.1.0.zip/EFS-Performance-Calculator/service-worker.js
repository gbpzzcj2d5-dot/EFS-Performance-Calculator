const CACHE_NAME = "efs-performance-v1";
const APP_SHELL = [
  "./", "./index.html", "./manifest.json",
  "./styles/base.css", "./styles/layout.css", "./styles/components.css", "./styles/responsive.css",
  "./src/app.js", "./src/router.js", "./src/i18n.js",
  "./src/database/storage.js", "./src/database/aircraft-store.js", "./src/database/airport-store.js",
  "./src/modules/dashboard/dashboard.js", "./src/modules/aircraft/aircraft.js", "./src/modules/airport/airport.js",
  "./src/validation/validator.js", "./assets/icons/icon.svg"
];
self.addEventListener("install", event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", event => {
  if (event.request.method !== "GET") return;
  event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request).then(response => {
    if (response.ok && new URL(event.request.url).origin === self.location.origin) {
      const copy = response.clone(); caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy));
    }
    return response;
  }).catch(() => caches.match("./index.html"))));
});
