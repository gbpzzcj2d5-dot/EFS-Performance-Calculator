import {t} from "../../i18n.js";
import {getCounts} from "../../database/storage.js";
import {listAircraft} from "../../database/aircraft-store.js";
import {listAirports} from "../../database/airport-store.js";
import {aircraftQuality,airportQuality} from "../../validation/validator.js";
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function qualityTag(status){return `<span class="tag ${status==="complete"?"good":status==="invalid"?"invalid":"partial"}">${status==="complete"?t("qualityComplete"):status==="invalid"?t("qualityInvalid"):t("qualityPartial")}</span>`;}
export async function renderDashboard(){
 const [counts,aircraft,airports]=await Promise.all([getCounts(),listAircraft(),listAirports()]);
 const completeA=aircraft.filter(a=>aircraftQuality(a).status==="complete").length;
 const completeP=airports.filter(a=>airportQuality(a).status==="complete").length;
 const recent=[...aircraft.map(a=>({name:a.name,sub:a.registration||a.manufacturer,at:a.updatedAt,kind:"aircraft",quality:aircraftQuality(a).status})),...airports.map(a=>({name:a.name,sub:[a.icao,a.iata].filter(Boolean).join(" / "),at:a.updatedAt,kind:"airport",quality:airportQuality(a).status}))].sort((a,b)=>new Date(b.at)-new Date(a.at)).slice(0,5);
 return `<div class="page-heading"><div><div class="eyebrow">${t("overview")}</div><h1 class="page-title">${t("dashboardTitle")}</h1><p class="page-subtitle">${t("dashboardSub")}</p></div></div>
 <section class="metrics-grid">
  <article class="panel metric-card"><div class="metric-accent"></div><div class="metric-label">${t("aircraftCount")}</div><div class="metric-value">${counts.aircraft.toString().padStart(2,"0")}</div><div class="metric-foot">${completeA} · ${t("qualityComplete")}</div></article>
  <article class="panel metric-card"><div class="metric-accent"></div><div class="metric-label">${t("airportCount")}</div><div class="metric-value">${counts.airports.toString().padStart(2,"0")}</div><div class="metric-foot">${completeP} · ${t("qualityComplete")}</div></article>
  <article class="panel metric-card"><div class="metric-accent"></div><div class="metric-label">${t("runwayCount")}</div><div class="metric-value">${counts.directions.toString().padStart(2,"0")}</div><div class="metric-foot">${counts.runways} ${t("runwayCountLabel")}</div></article>
  <article class="panel metric-card"><div class="metric-accent"></div><div class="metric-label">${t("dataIntegrity")}</div><div class="metric-value">${aircraft.length+airports.length?Math.round((completeA+completeP)/(aircraft.length+airports.length)*100):0}<span style="font-size:14px">%</span></div><div class="metric-foot">${t("unverified")}</div></article>
 </section>
 <section class="dashboard-grid">
  <article class="panel"><div class="panel-header"><h2 class="panel-title">${t("quickActions")}</h2><span class="panel-kicker">NAVIGATION</span></div><div class="panel-body"><div class="quick-grid">
   <a class="quick-link" href="#aircraft"><span class="quick-icon">✈</span><span><strong>${t("manageAircraft")}</strong><small>${t("aircraftDesc")}</small></span></a>
   <a class="quick-link" href="#airports"><span class="quick-icon">▤</span><span><strong>${t("manageAirports")}</strong><small>${t("airportDesc")}</small></span></a>
   <div class="quick-link" style="opacity:.55"><span class="quick-icon">◉</span><span><strong>${t("flightConditions")}</strong><small>${t("comingNext")}</small></span></div>
   <div class="quick-link" style="opacity:.55"><span class="quick-icon">↗</span><span><strong>${t("performance")}</strong><small>${t("comingNext")}</small></span></div>
  </div></div></article>
  <article class="panel"><div class="panel-header"><h2 class="panel-title">${t("recentRecords")}</h2><span class="panel-kicker">LOCAL DATABASE</span></div><div class="panel-body">${recent.length?`<div class="data-list">${recent.map(r=>`<div class="data-row"><div class="data-row-main"><strong>${esc(r.name)}</strong><small>${esc(r.sub||"—")} · ${r.kind==="aircraft"?t("aircraft"):t("airports")}</small></div>${qualityTag(r.quality)}</div>`).join("")}</div>`:`<div class="empty-state"><div class="empty-icon">⌁</div><strong>${t("recentRecords")}</strong><p>${t("recentEmpty")}</p></div>`}</div></article>
 </section>
 <div class="notice" style="margin-top:16px">${t("dataNote")} ${t("dataSourceNote")}</div>`;
}
