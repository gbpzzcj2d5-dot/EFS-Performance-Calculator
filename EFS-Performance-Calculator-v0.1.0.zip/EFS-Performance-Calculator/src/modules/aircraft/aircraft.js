import {t} from "../../i18n.js";
import {listAircraft,saveAircraft,deleteAircraft} from "../../database/aircraft-store.js";
import {aircraftQuality,validateAircraftForm,numberOrNull} from "../../validation/validator.js";
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const val=v=>v==null?"":v;
function tag(q){return `<span class="tag ${q.status==="complete"?"good":q.status==="invalid"?"invalid":"partial"}">${q.status==="complete"?t("qualityComplete"):q.status==="invalid"?t("qualityInvalid"):t("qualityPartial")}</span>`;}
function field(label,name,value="",type="text",hint=""){return `<div class="field"><label for="${name}">${label}</label><input id="${name}" name="${name}" type="${type}" value="${esc(value)}" ${type==="number"?'step="any"':''} placeholder="—">${hint?`<span class="field-hint">${hint}</span>`:""}</div>`;}
export async function renderAircraft(){
 const records=await listAircraft();
 return `<div class="page-heading"><div><div class="eyebrow">${t("aircraftManagement")}</div><h1 class="page-title">${t("aircraftTitle")}</h1><p class="page-subtitle">${t("aircraftSub")}</p></div><button class="primary-button" id="addAircraft">＋ ${t("createAircraft")}</button></div>
 <div class="toolbar"><input class="search-input" id="aircraftSearch" type="search" placeholder="${t("searchAircraft")}"><span class="tag">${records.length} ${t("aircraftCount")}</span></div>
 <section class="panel list-panel"><div class="record-list" id="aircraftList">${records.length?records.map(renderCard).join(""):`<div class="empty-state"><div class="empty-icon">✈</div><strong>${t("noAircraft")}</strong><p>${t("aircraftSub")}</p><button class="primary-button" id="emptyAddAircraft">${t("startAircraft")}</button></div>`}</div></section>
 <p class="quality-note" style="margin-top:12px">${t("dataNote")} ${t("dataSourceNote")}</p>`;
}
function renderCard(a){
 const q=aircraftQuality(a);
 return `<article class="record-card" data-search="${esc([a.name,a.manufacturer,a.registration,a.aircraftType].join(" ").toLowerCase())}"><div class="record-avatar">✈</div><div class="record-info"><strong>${esc(a.name)}</strong><small>${esc([a.manufacturer,a.aircraftType,a.registration].filter(Boolean).join(" · ")||"—")}</small><div class="record-meta">${tag(q)}<span class="tag">${a.engineCount} × ${esc(a.engineType||"—")}</span><span class="tag">MTOW ${a.weights?.mtowKg??"—"} kg</span></div></div><div class="record-actions"><button class="small-button" data-edit-aircraft="${a.id}">${t("edit")}</button><button class="small-button delete" data-delete-aircraft="${a.id}">${t("delete")}</button></div></article>`;
}
export function openAircraftDialog(existing,dialog,refresh,toast){
 const a=existing||{id:null,name:"",manufacturer:"",aircraftType:"",registration:"",engineCount:2,engineType:"turbofan",weights:{},aerodynamics:{},engines:{},configurations:{}};
 const title=existing?t("editAircraft"):t("newAircraft");
 document.getElementById("dialogContent").innerHTML=`<div class="dialog-head"><div><h2>${title}</h2><p>${t("dataSourceNote")}</p></div><button class="dialog-close" id="closeDialog" aria-label="Close">×</button></div>
 <form class="dialog-form" id="aircraftForm">
 <section class="form-section"><h3 class="form-section-title">${t("basicInfo")}</h3><div class="form-grid">
 ${field(t("name")+" *","name",a.name)}${field(t("manufacturer"),"manufacturer",a.manufacturer)}
 <div class="field"><label>${t("aircraftType")}</label><select name="aircraftType"><option value="">—</option>${["wideBody","narrowBody","regional","generalAviation","other"].map(k=>`<option value="${k}" ${a.aircraftType===k?"selected":""}>${t(k)}</option>`).join("")}</select></div>
 ${field(t("registration"),"registration",a.registration)}
 ${field(t("engineCount"),"engineCount",a.engineCount,"number")}
 <div class="field"><label>${t("engineType")}</label><select name="engineType">${["turbofan","turboprop","piston","electric","other"].map(k=>`<option value="${k}" ${a.engineType===k?"selected":""}>${t(k)}</option>`).join("")}</select></div>
 </div></section>
 <section class="form-section"><h3 class="form-section-title">${t("weights")}</h3><div class="form-grid">
 ${field(t("oew"),"oewKg",val(a.weights?.oewKg),"number")}${field(t("mtow"),"mtowKg",val(a.weights?.mtowKg),"number")}
 ${field(t("mlw"),"mlwKg",val(a.weights?.mlwKg),"number")}${field(t("mzfw"),"mzfwKg",val(a.weights?.mzfwKg),"number")}
 ${field(t("payload"),"maximumPayloadKg",val(a.weights?.maximumPayloadKg),"number")}
 </div></section>
 <section class="form-section"><h3 class="form-section-title">${t("aerodynamics")}</h3><div class="form-grid">
 ${field(t("wingArea"),"wingAreaM2",val(a.aerodynamics?.wingAreaM2),"number")}${field(t("aspectRatio"),"aspectRatio",val(a.aerodynamics?.aspectRatio),"number")}
 ${field(t("clmax"),"clMax",val(a.aerodynamics?.clMax),"number")}${field(t("cd0"),"cd0",val(a.aerodynamics?.cd0),"number")}
 ${field(t("oswald"),"oswaldEfficiency",val(a.aerodynamics?.oswaldEfficiency),"number")}
 </div></section>
 <section class="form-section"><h3 class="form-section-title">${t("engines")}</h3><div class="form-grid">${field(t("maxThrust"),"maximumStaticThrustN",val(a.engines?.maximumStaticThrustN),"number")}</div></section>
 <section class="form-section"><h3 class="form-section-title">${t("configurations")}</h3><div class="form-grid">
 ${field(t("flapConfig"),"flapConfigurations",Array.isArray(a.configurations?.flaps)?a.configurations.flaps.join(", "):"")}
 ${field(t("gearConfig"),"gearConfiguration",a.configurations?.gear||"")}
 ${field(t("brakingConfig"),"brakingConfiguration",a.configurations?.braking||"")}
 ${field(t("spoilerConfig"),"spoilerConfiguration",a.configurations?.spoilers||"")}
 <div class="field"><label><input type="checkbox" name="reverse" style="width:auto;height:auto" ${a.configurations?.reverseThrust?"checked":""}> ${t("reverse")}</label></div>
 <div class="field"><label><input type="checkbox" name="antiSkid" style="width:auto;height:auto" ${a.configurations?.antiSkid?"checked":""}> ${t("antiSkid")}</label></div>
 </div></section>
 <p class="form-error" id="formError" hidden></p><div class="form-actions"><button type="button" class="secondary-button" id="cancelDialog">${t("cancel")}</button><button class="primary-button" type="submit">${t("save")}</button></div></form>`;
 const close=()=>dialog.close(); document.getElementById("closeDialog").onclick=close;document.getElementById("cancelDialog").onclick=close;
 document.getElementById("aircraftForm").onsubmit=async e=>{
  e.preventDefault();const f=new FormData(e.currentTarget);
  const now=new Date().toISOString();
  const record={id:a.id||crypto.randomUUID(),name:String(f.get("name")||"").trim(),manufacturer:String(f.get("manufacturer")||"").trim(),aircraftType:f.get("aircraftType")||"",registration:String(f.get("registration")||"").trim(),engineCount:Number(f.get("engineCount")),engineType:f.get("engineType"),weights:{oewKg:numberOrNull(f.get("oewKg")),mtowKg:numberOrNull(f.get("mtowKg")),mlwKg:numberOrNull(f.get("mlwKg")),mzfwKg:numberOrNull(f.get("mzfwKg")),maximumPayloadKg:numberOrNull(f.get("maximumPayloadKg"))},aerodynamics:{wingAreaM2:numberOrNull(f.get("wingAreaM2")),aspectRatio:numberOrNull(f.get("aspectRatio")),clMax:numberOrNull(f.get("clMax")),cd0:numberOrNull(f.get("cd0")),oswaldEfficiency:numberOrNull(f.get("oswaldEfficiency"))},engines:{maximumStaticThrustN:numberOrNull(f.get("maximumStaticThrustN"))},configurations:{flaps:String(f.get("flapConfigurations")||"").split(",").map(s=>s.trim()).filter(Boolean),gear:String(f.get("gearConfiguration")||""),braking:String(f.get("brakingConfiguration")||""),spoilers:String(f.get("spoilerConfiguration")||""),reverseThrust:f.has("reverse"),antiSkid:f.has("antiSkid")},createdAt:a.createdAt||now,updatedAt:now,schemaVersion:1};
  const error=validateAircraftForm(record);const errorEl=document.getElementById("formError");
  if(error){errorEl.textContent=t(error);errorEl.hidden=false;return;}
  if(Object.values(record.weights).some(v=>Number.isNaN(v))||Object.values(record.aerodynamics).some(v=>Number.isNaN(v))||Number.isNaN(record.engines.maximumStaticThrustN)){errorEl.textContent=t("validationNumber");errorEl.hidden=false;return;}
  await saveAircraft(record);dialog.close();toast(t("saved"));await refresh();
 };
 dialog.showModal();
}
export async function bindAircraftPage(dialog,refresh,toast){
 document.getElementById("addAircraft")?.addEventListener("click",()=>openAircraftDialog(null,dialog,refresh,toast));
 document.getElementById("emptyAddAircraft")?.addEventListener("click",()=>openAircraftDialog(null,dialog,refresh,toast));
 document.getElementById("aircraftSearch")?.addEventListener("input",e=>{const q=e.target.value.toLowerCase();document.querySelectorAll("#aircraftList .record-card").forEach(el=>el.hidden=!el.dataset.search.includes(q));});
 document.querySelectorAll("[data-edit-aircraft]").forEach(b=>b.addEventListener("click",async()=>{const a=(await listAircraft()).find(x=>x.id===b.dataset.editAircraft);if(a)openAircraftDialog(a,dialog,refresh,toast);}));
 document.querySelectorAll("[data-delete-aircraft]").forEach(b=>b.addEventListener("click",async()=>{if(confirm(t("confirmDeleteAircraft"))){await deleteAircraft(b.dataset.deleteAircraft);toast(t("deleted"));await refresh();}}));
}
