import {t} from "../../i18n.js";
import {listAirports,saveAirport,deleteAirport} from "../../database/airport-store.js";
import {airportQuality,validateAirportForm,numberOrNull} from "../../validation/validator.js";
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function qualityTag(q){return `<span class="tag ${q.status==="complete"?"good":q.status==="invalid"?"invalid":"partial"}">${q.status==="complete"?t("qualityComplete"):q.status==="invalid"?t("qualityInvalid"):t("qualityPartial")}</span>`;}
function field(label,name,value="",type="text"){return `<div class="field"><label>${label}</label><input name="${name}" type="${type}" value="${esc(value??"")}" ${type==="number"?'step="any"':''} placeholder="—"></div>`;}
export async function renderAirports(){
 const records=await listAirports();
 return `<div class="page-heading"><div><div class="eyebrow">${t("airportManagement")}</div><h1 class="page-title">${t("airportTitle")}</h1><p class="page-subtitle">${t("airportSub")}</p></div><button class="primary-button" id="addAirport">＋ ${t("createAirport")}</button></div>
 <div class="toolbar"><input class="search-input" id="airportSearch" type="search" placeholder="${t("searchAirport")}"><span class="tag">${records.length} ${t("airportCount")}</span></div>
 <section class="panel list-panel"><div class="record-list" id="airportList">${records.length?records.map(renderCard).join(""):`<div class="empty-state"><div class="empty-icon">▤</div><strong>${t("noAirports")}</strong><p>${t("airportHint")}</p><button class="primary-button" id="emptyAddAirport">${t("startAirport")}</button></div>`}</div></section>
 <p class="quality-note" style="margin-top:12px">${t("airportHint")} ${t("dataNote")}</p>`;
}
function renderCard(a){
 const q=airportQuality(a),runways=a.runways||[];
 return `<article class="record-card" data-search="${esc([a.name,a.icao,a.iata,a.country].join(" ").toLowerCase())}"><div class="record-avatar">▤</div><div class="record-info"><strong>${esc(a.name)}</strong><small>${esc([a.icao,a.iata,a.country].filter(Boolean).join(" · ")||"—")} · ${a.elevationM??"—"} m</small><div class="record-meta">${qualityTag(q)}<span class="tag">${runways.length} ${t("runwayCountLabel")}</span>${runways.map(r=>`<span class="tag">${esc(r.designation)}</span>`).join("")}</div></div><div class="record-actions"><button class="small-button" data-edit-airport="${a.id}">${t("edit")}</button><button class="small-button delete" data-delete-airport="${a.id}">${t("delete")}</button></div></article>`;
}
function runwayEditor(r,index){
 return `<div class="subsection runway-editor" data-runway-index="${index}" data-id="${esc(r.id||"")}"><div class="subsection-head"><strong>${t("runwayInfo")} ${index+1}</strong><button type="button" class="small-button delete remove-runway">${t("remove")}</button></div>
 <div class="form-grid">
 ${field(t("designation")+" *","designation",r.designation)}
 ${field(t("physicalLength"),"physicalLengthM",r.physicalLengthM,"number")}
 ${field(t("width"),"widthM",r.widthM,"number")}
 ${field(t("heading"),"headingDeg",r.headingDeg,"number")}
 ${field(t("slope"),"slopePercent",r.slopePercent,"number")}
 <div class="field"><label>${t("surface")}</label><select name="surfaceType">${["asphalt","concrete","gravel","grass","otherSurface"].map(k=>`<option value="${k}" ${r.surfaceType===k?"selected":""}>${t(k)}</option>`).join("")}</select></div>
 </div>
 <div class="runway-directions">${(r.directions||[{designation:"",toraM:null,todaM:null,asdaM:null,ldaM:null,slopePercent:null}]).map((d,di)=>directionEditor(d,di)).join("")}</div>
 <button type="button" class="small-button add-direction" style="margin-top:10px">＋ ${t("direction")}</button>
 </div>`;
}
function directionEditor(d,index){
 return `<div class="runway-direction" data-direction-index="${index}" data-id="${esc(d.id||"")}"><div class="runway-direction-title">${t("direction")} ${index+1}</div><div class="inline-runway">
 <input name="directionDesignation" aria-label="${t("direction")}" placeholder="${t("designation")}" value="${esc(d.designation)}">
 <input name="toraM" aria-label="TORA" type="number" step="any" placeholder="TORA" value="${d.toraM??""}">
 <input name="todaM" aria-label="TODA" type="number" step="any" placeholder="TODA" value="${d.todaM??""}">
 <input name="asdaM" aria-label="ASDA" type="number" step="any" placeholder="ASDA" value="${d.asdaM??""}">
 <input name="ldaM" aria-label="LDA" type="number" step="any" placeholder="LDA" value="${d.ldaM??""}">
 <input name="directionSlopePercent" aria-label="${t("directionSlope")}" type="number" step="any" placeholder="${t("directionSlope")}" value="${d.slopePercent??""}">
 <button type="button" class="small-button delete remove-direction">${t("remove")}</button>
 </div></div>`;
}
export function openAirportDialog(existing,dialog,refresh,toast){
 const a=existing||{id:null,name:"",icao:"",iata:"",elevationM:null,country:"",latitude:null,longitude:null,runways:[]};
 let runways=structuredClone(a.runways||[]);
 const title=existing?t("editAirport"):t("newAirport");
 document.getElementById("dialogContent").innerHTML=`<div class="dialog-head"><div><h2>${title}</h2><p>${t("airportHint")}</p></div><button class="dialog-close" id="closeDialog">×</button></div>
 <form class="dialog-form" id="airportForm">
 <section class="form-section"><h3 class="form-section-title">${t("airportInfo")}</h3><div class="form-grid">
 ${field(t("airportName")+" *","name",a.name)}${field(t("country"),"country",a.country)}
 ${field(t("icao"),"icao",a.icao)}${field(t("iata"),"iata",a.iata)}
 ${field(t("elevation"),"elevationM",a.elevationM,"number")}${field(t("latitude"),"latitude",a.latitude,"number")}
 ${field(t("longitude"),"longitude",a.longitude,"number")}
 </div></section>
 <section class="form-section"><div class="subsection-head"><h3 class="form-section-title" style="margin:0">${t("runways")}</h3><button type="button" class="secondary-button" id="addRunway">＋ ${t("addRunway")}</button></div><div id="runwayEditors">${runways.map(runwayEditor).join("")}</div></section>
 <div class="notice">${t("runwayHint")}</div><p class="form-error" id="formError" hidden></p><div class="form-actions"><button type="button" class="secondary-button" id="cancelDialog">${t("cancel")}</button><button type="submit" class="primary-button">${t("save")}</button></div>
 </form>`;
 const dialogEl=dialog,close=()=>dialogEl.close();
 document.getElementById("closeDialog").onclick=close;document.getElementById("cancelDialog").onclick=close;
 const container=document.getElementById("runwayEditors");
 const bindRunwayButtons=()=>{
  container.querySelectorAll(".remove-runway").forEach(b=>b.onclick=()=>{b.closest(".runway-editor").remove();});
  container.querySelectorAll(".add-direction").forEach(b=>b.onclick=()=>{const editor=b.closest(".runway-editor"),dirs=editor.querySelector(".runway-directions");dirs.insertAdjacentHTML("beforeend",directionEditor({designation:"",toraM:null,todaM:null,asdaM:null,ldaM:null,slopePercent:null},dirs.children.length));bindRunwayButtons();});
  container.querySelectorAll(".remove-direction").forEach(b=>b.onclick=()=>{b.closest(".runway-direction").remove();});
 };
 bindRunwayButtons();
 document.getElementById("addRunway").onclick=()=>{container.insertAdjacentHTML("beforeend",runwayEditor({designation:"",physicalLengthM:null,widthM:null,headingDeg:null,slopePercent:null,surfaceType:"asphalt",directions:[{designation:"",toraM:null,todaM:null,asdaM:null,ldaM:null,slopePercent:null}]},container.children.length));bindRunwayButtons();};
 document.getElementById("airportForm").onsubmit=async e=>{
  e.preventDefault();const form=e.currentTarget,f=new FormData(form);
  const collect=(selector,names)=>[...container.querySelectorAll(selector)].map(el=>{const o={};names.forEach(n=>{const input=el.querySelector(`[name="${n}"]`);o[n]=input?input.value:null;});return o;});
  const runwayEls=[...container.querySelectorAll(".runway-editor")];
  const parsedRunways=runwayEls.map(el=>{
   const get=n=>el.querySelector(`[name="${n}"]`)?.value??"";
   const directions=[...el.querySelectorAll(".runway-direction")].map(de=>{const g=n=>de.querySelector(`[name="${n}"]`)?.value??"";return {id:de.dataset.id||crypto.randomUUID(),designation:g("directionDesignation").trim(),toraM:numberOrNull(g("toraM")),todaM:numberOrNull(g("todaM")),asdaM:numberOrNull(g("asdaM")),ldaM:numberOrNull(g("ldaM")),slopePercent:numberOrNull(g("directionSlopePercent"))};});
   return {id:el.dataset.id||crypto.randomUUID(),designation:get("designation").trim(),physicalLengthM:numberOrNull(get("physicalLengthM")),widthM:numberOrNull(get("widthM")),headingDeg:numberOrNull(get("headingDeg")),slopePercent:numberOrNull(get("slopePercent")),surfaceType:get("surfaceType"),directions};
  });
  const now=new Date().toISOString();
  const record={id:a.id||crypto.randomUUID(),name:String(f.get("name")||"").trim(),icao:String(f.get("icao")||"").trim().toUpperCase(),iata:String(f.get("iata")||"").trim().toUpperCase(),elevationM:numberOrNull(f.get("elevationM")),country:String(f.get("country")||"").trim(),latitude:numberOrNull(f.get("latitude")),longitude:numberOrNull(f.get("longitude")),runways:parsedRunways,createdAt:a.createdAt||now,updatedAt:now,schemaVersion:1};
  const err=validateAirportForm(record),errorEl=document.getElementById("formError");
  const numeric=[record.elevationM,record.latitude,record.longitude,...parsedRunways.flatMap(r=>[r.physicalLengthM,r.widthM,r.headingDeg,r.slopePercent,...r.directions.flatMap(d=>[d.toraM,d.todaM,d.asdaM,d.ldaM,d.slopePercent])])];
  if(err||numeric.some(Number.isNaN)){errorEl.textContent=t(err||"validationNumber");errorEl.hidden=false;return;}
  await saveAirport(record);dialog.close();toast(t("saved"));await refresh();
 };
 dialog.showModal();
}
export async function bindAirportPage(dialog,refresh,toast){
 document.getElementById("addAirport")?.addEventListener("click",()=>openAirportDialog(null,dialog,refresh,toast));
 document.getElementById("emptyAddAirport")?.addEventListener("click",()=>openAirportDialog(null,dialog,refresh,toast));
 document.getElementById("airportSearch")?.addEventListener("input",e=>{const q=e.target.value.toLowerCase();document.querySelectorAll("#airportList .record-card").forEach(el=>el.hidden=!el.dataset.search.includes(q));});
 document.querySelectorAll("[data-edit-airport]").forEach(b=>b.addEventListener("click",async()=>{const a=(await listAirports()).find(x=>x.id===b.dataset.editAirport);if(a)openAirportDialog(a,dialog,refresh,toast);}));
 document.querySelectorAll("[data-delete-airport]").forEach(b=>b.addEventListener("click",async()=>{if(confirm(t("confirmDeleteAirport"))){await deleteAirport(b.dataset.deleteAirport);toast(t("deleted"));await refresh();}}));
}
