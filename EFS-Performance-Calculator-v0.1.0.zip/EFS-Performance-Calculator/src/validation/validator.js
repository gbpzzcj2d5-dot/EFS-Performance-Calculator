export function numberOrNull(value){
  if(value===null||value===undefined||String(value).trim()==="") return null;
  const n=Number(value); return Number.isFinite(n)?n:NaN;
}
export function aircraftQuality(a){
  const errors=[];
  const w=a.weights||{};
  const vals=["oewKg","mtowKg","mlwKg","mzfwKg"].map(k=>w[k]).filter(v=>v!==null&&v!==undefined);
  if(vals.some(v=>!Number.isFinite(v)||v<0)) errors.push("Invalid weight value");
  if(w.oewKg!=null&&w.mtowKg!=null&&w.oewKg>w.mtowKg) errors.push("OEW exceeds MTOW");
  if(w.mzfwKg!=null&&w.mtowKg!=null&&w.mzfwKg>w.mtowKg) errors.push("MZFW exceeds MTOW");
  if(w.mlwKg!=null&&w.mtowKg!=null&&w.mlwKg>w.mtowKg) errors.push("MLW exceeds MTOW");
  if(!Number.isInteger(a.engineCount)||a.engineCount<1) errors.push("Invalid engine count");
  if(errors.length) return {status:"invalid",errors};
  const required=[a.name,a.manufacturer,a.aircraftType,a.engineType,w.oewKg,w.mtowKg,w.mlwKg,w.mzfwKg,a.aerodynamics?.wingAreaM2,a.engines?.maximumStaticThrustN];
  const filled=required.filter(v=>v!==null&&v!==undefined&&v!=="").length;
  return {status:filled===required.length?"complete":"partial",filled,total:required.length,errors:[]};
}
export function airportQuality(a){
  const errors=[];
  if(!a.name) errors.push("Missing airport name");
  for(const r of a.runways||[]){
    if(!r.designation) errors.push("Missing runway designation");
    for(const d of r.directions||[]){
      for(const k of ["toraM","todaM","asdaM","ldaM"]) if(d[k]!=null&&(!Number.isFinite(d[k])||d[k]<0)) errors.push("Invalid declared distance");
      if(r.physicalLengthM!=null) for(const k of ["toraM","todaM","asdaM","ldaM"]) if(d[k]!=null&&d[k]>r.physicalLengthM) errors.push("Declared distance exceeds physical length");
    }
  }
  if(errors.length) return {status:"invalid",errors};
  const complete=!!(a.name&&a.icao&&a.elevationM!=null&&(a.runways||[]).length>0&&(a.runways||[]).every(r=>r.designation&&(r.directions||[]).length>0&&r.directions.every(d=>["toraM","todaM","asdaM","ldaM"].every(k=>d[k]!=null))));
  return {status:complete?"complete":"partial",errors:[]};
}
export function validateAircraftForm(a){
  if(!a.name?.trim()) return "validationName";
  if(!Number.isInteger(a.engineCount)||a.engineCount<1) return "validationEngine";
  const q=aircraftQuality(a); if(q.status==="invalid") return "validationWeight";
  return null;
}
export function validateAirportForm(a){
  if(!a.name?.trim()) return "validationName";
  if(a.icao&&!/^[A-Za-z]{4}$/.test(a.icao)) return "validationIcao";
  if(!a.runways?.length||a.runways.some(r=>!r.designation?.trim()||!r.directions?.length||r.directions.some(d=>!d.designation?.trim()))) return "validationRunway";
  if(airportQuality(a).status==="invalid") return "validationDistance";
  return null;
}
