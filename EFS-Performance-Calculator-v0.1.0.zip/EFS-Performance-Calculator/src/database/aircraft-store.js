import {getAll,put,remove} from "./storage.js";
export const listAircraft=()=>getAll("aircraft");
export const saveAircraft=record=>put("aircraft",record);
export const deleteAircraft=id=>remove("aircraft",id);
