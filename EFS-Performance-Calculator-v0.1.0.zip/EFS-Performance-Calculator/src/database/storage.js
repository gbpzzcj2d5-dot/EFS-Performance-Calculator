const DB_NAME = "efs-performance-calculator";
const DB_VERSION = 1;
let dbPromise;
export function openDatabase(){
  if (!("indexedDB" in window)) return Promise.reject(new Error("IndexedDB is not supported in this browser."));
  if (!dbPromise) dbPromise = new Promise((resolve,reject)=>{
    const request = indexedDB.open(DB_NAME,DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains("aircraft")) db.createObjectStore("aircraft",{keyPath:"id"});
      if (!db.objectStoreNames.contains("airports")) db.createObjectStore("airports",{keyPath:"id"});
      if (!db.objectStoreNames.contains("results")) db.createObjectStore("results",{keyPath:"id"});
      if (!db.objectStoreNames.contains("conditions")) db.createObjectStore("conditions",{keyPath:"id"});
      if (!db.objectStoreNames.contains("meta")) db.createObjectStore("meta",{keyPath:"key"});
    };
    request.onsuccess=()=>resolve(request.result);
    request.onerror=()=>reject(request.error || new Error("Unable to open local database."));
  });
  return dbPromise;
}
export async function getAll(storeName){
  const db=await openDatabase();
  return new Promise((resolve,reject)=>{const tx=db.transaction(storeName,"readonly");const req=tx.objectStore(storeName).getAll();req.onsuccess=()=>resolve(req.result||[]);req.onerror=()=>reject(req.error);});
}
export async function put(storeName,value){
  const db=await openDatabase();
  return new Promise((resolve,reject)=>{const tx=db.transaction(storeName,"readwrite");tx.objectStore(storeName).put(value);tx.oncomplete=()=>resolve(value);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error);});
}
export async function remove(storeName,id){
  const db=await openDatabase();
  return new Promise((resolve,reject)=>{const tx=db.transaction(storeName,"readwrite");tx.objectStore(storeName).delete(id);tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);});
}
export async function getCounts(){
  const [aircraft,airports]=await Promise.all([getAll("aircraft"),getAll("airports")]);
  return {aircraft:aircraft.length,airports:airports.length,runways:airports.reduce((n,a)=>n+(a.runways||[]).length,0),directions:airports.reduce((n,a)=>n+(a.runways||[]).reduce((m,r)=>m+(r.directions||[]).length,0),0)};
}
export const SCHEMA_VERSION=1;
