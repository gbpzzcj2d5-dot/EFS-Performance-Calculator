import {getAll,put,remove} from "./storage.js";
export const listAirports=()=>getAll("airports");
export const saveAirport=record=>put("airports",record);
export const deleteAirport=id=>remove("airports",id);
