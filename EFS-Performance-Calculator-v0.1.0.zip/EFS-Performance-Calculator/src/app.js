import {t,getLanguage,setLanguage} from "./i18n.js";
import {getRoute,onRouteChange} from "./router.js";
import {renderDashboard} from "./modules/dashboard/dashboard.js";
import {renderAircraft,bindAircraftPage} from "./modules/aircraft/aircraft.js";
import {renderAirports,bindAirportPage} from "./modules/airport/airport.js";
import {openDatabase} from "./database/storage.js";
const content=document.getElementById("appContent"),dialog=document.getElementById("recordDialog");
function toast(message,error=false){const el=document.createElement("div");el.className=`toast${error?" error":""}`;el.textContent=message;document.getElementById("toastRegion").append(el);setTimeout(()=>el.remove(),2600);}
async function render(){
 try{
  const route=getRoute();document.querySelectorAll("[data-route]").forEach(a=>a.classList.toggle("active",a.dataset.route===route));
  const labels={dashboard:t("dashboardCrumb"),aircraft:t("aircraftCrumb"),airports:t("airportCrumb")};
  document.getElementById("breadcrumbCurrent").textContent=labels[route];
  if(route==="dashboard")content.innerHTML=await renderDashboard();
  if(route==="aircraft"){content.innerHTML=await renderAircraft();await bindAircraftPage(dialog,render,toast);}
  if(route==="airports"){content.innerHTML=await renderAirports();await bindAirportPage(dialog,render,toast);}
  document.getElementById("aircraftNavCount").textContent=document.querySelectorAll("#aircraftList .record-card").length||"";
  if(route!=="aircraft"){const {listAircraft}=await import("./database/aircraft-store.js");document.getElementById("aircraftNavCount").textContent=(await listAircraft()).length;}
  if(route!=="airports"){const {listAirports}=await import("./database/airport-store.js");document.getElementById("airportNavCount").textContent=(await listAirports()).length;}
  document.getElementById("appContent").focus({preventScroll:true});
 }catch(error){console.error(error);content.innerHTML=`<div class="notice">Application error: ${String(error.message||error)}</div>`;}
}
document.getElementById("languageButton").addEventListener("click",()=>{setLanguage(getLanguage()==="zh"?"en":"zh");updateStaticText();render();});
function updateStaticText(){document.querySelectorAll("[data-i18n]").forEach(el=>el.textContent=t(el.dataset.i18n));document.getElementById("languageButton").textContent=getLanguage()==="zh"?"EN":"中文";document.documentElement.lang=getLanguage()==="zh"?"zh-CN":"en";}
document.getElementById("menuButton").addEventListener("click",()=>document.getElementById("sidebar").classList.toggle("open"));
document.querySelectorAll("[data-route]").forEach(a=>a.addEventListener("click",()=>document.getElementById("sidebar").classList.remove("open")));
onRouteChange(()=>{document.getElementById("sidebar").classList.remove("open");render();});
(async()=>{try{await openDatabase();}catch(e){toast("IndexedDB unavailable: "+e.message,true);}updateStaticText();await render();if("serviceWorker" in navigator && location.protocol!=="file:"){navigator.serviceWorker.register("./service-worker.js").catch(console.warn);}})();
