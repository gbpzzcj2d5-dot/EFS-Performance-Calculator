export function getRoute(){const raw=location.hash.replace(/^#/,"");return ["dashboard","aircraft","airports"].includes(raw)?raw:"dashboard";}
export function onRouteChange(callback){window.addEventListener("hashchange",callback);}
