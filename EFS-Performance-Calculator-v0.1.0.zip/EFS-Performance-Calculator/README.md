# EFS Performance Calculator — v0.1.0

第一阶段交付：Dashboard、Aircraft Manager、Airport Manager。

## 技术方案
- 原生 HTML / CSS / JavaScript ES Modules，无构建步骤。
- IndexedDB 本地持久化；LocalStorage 仅保存语言偏好。
- Mobile-first 响应式布局，支持 iPhone Safari。
- PWA Manifest + Service Worker 基础离线缓存。
- 内部 SI 单位：质量 kg、距离 m、面积 m²、推力 N、温度/气压等字段按规格扩展。
- 数据对象包含 `schemaVersion: 1`、`createdAt`、`updatedAt`。

## 启动
推荐通过本地 HTTP 服务运行（不要直接双击 `index.html`，因为 ES Modules、Service Worker 需要安全上下文）：

```bash
cd EFS-Performance-Calculator
python3 -m http.server 8000
```

浏览器访问 `http://localhost:8000`。

部署到 HTTPS 静态托管后，可在 iPhone Safari 中打开并通过“分享 → 添加到主屏幕”安装。

## 当前实现
1. Dashboard：飞机、机场、跑道方向数量；档案完整性概览；最近更新；快捷入口。
2. Aircraft Manager：飞机档案 CRUD；基本信息、重量、气动、动力、构型字段；数据逻辑检查；搜索。
3. Airport Manager：机场档案 CRUD；一个机场多条跑道；每条跑道多个方向；方向独立 TORA/TODA/ASDA/LDA 和坡度；搜索。
4. 中英文切换。
5. IndexedDB 持久化。
6. PWA 基础缓存。

## 数据准确性边界
- 空值保存为 `null`，不以 0 代替未知值。
- 物理跑道长度不会自动填入 TORA/TODA/ASDA/LDA。
- Data Quality 仅检查字段完整性与基本逻辑，不代表数据经过来源验证。
- 本版本不包含任何预置飞机、机场或真实性能数据。
- 当前没有执行起飞/着陆性能计算；后续阶段完成计算引擎后再开放相关入口。
- 本工具仅供学习、研究和模拟，不用于真实航空运行放行。

## 注意
- Service Worker 首次加载需要联网或至少能成功缓存全部应用资源。此版本的字体通过 Google Fonts CDN 加载；核心功能不依赖字体 CDN，但首次离线时可能使用系统字体。
- 删除机场会删除其所含跑道档案。当前尚无运行条件或计算结果模块引用机场，因此不涉及级联历史记录。
